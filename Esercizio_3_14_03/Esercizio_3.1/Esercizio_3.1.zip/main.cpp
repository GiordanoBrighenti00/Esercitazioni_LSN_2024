/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include "random.h"
#include <cmath>

using namespace std;

double max(double a, double b){
  if (a>b) return a;
  else return b;

} 
 
int main (int argc, char *argv[]){

   Random rnd;
   int seed[5];
   int p1, p2;
   ifstream Primes("Primes");
   if (Primes.is_open()){
      Primes >> p1 >> p2 ;
   } else cerr << "PROBLEM: Unable to open Primes" << endl;
   Primes.close();

   ifstream input("seed.in");
   string property;
   if (input.is_open()){
      while ( !input.eof() ){
         input >> property;
         if( property == "RANDOMSEED" ){
            input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
            rnd.SetRandom(seed,p1,p2);
         }
      }
      input.close();
   } else cerr << "PROBLEM: Unable to open seed.in" << endl;

   for(int i=0; i<20; i++){
      //cout << rnd.Rannyu() << endl;
   }

   rnd.SaveSeed();

  // Esercizio 3.1: Calcolare call option C[S(0),0] e put option P[S(0),0], attraverso il calcolo di S(t) (prezzo spot)

  double K = 100; // strike price
  double r = 0.1; // risk-free interest rate
  double sigma = 0.25; // volatility
  double S_0 = 100; // spot price iniziale
  double T = 1; // delivery time

  // Calcolo diretto di S(t)

  ofstream out_C("Call-Option.txt");
  ofstream out_P("Put-Option.txt");

  int N1 = 50;  // Numero di Blocchi
  int N2 = 2500; // Numero di stime in ogni blocco 

  double C_ave_tot = 0;  // Media globale:media delle medie sui blocchi // call option
  double C_var_tot = 0;    // Incertezza globale come deviazione standard della media

  double P_ave_tot = 0;  // Media globale:media delle medie sui blocchi // put option
  double P_var_tot = 0;    // Incertezza globale come deviazione standard della media

  // Deviazione standard della media su N1 blocchi: la variabile "A_i" è la stima della call C su ciascun blocco

  for(int j=0; j<N1; j++){

    double C  = 0; // Inizializzo la variabile associata al prezzo della call-option
    double P  = 0; // Inizializzo la variabile associata al prezzo della put-option
    
    for(int i=0; i<N2; i++){    // Blocco j-esimo: ripeto N2 volte la stima di S(t) per calcolare la Call C
      double S_T = S_0 *exp((r - 0.5 * sigma*sigma) * T + sigma*rnd.Gauss(0,sqrt(T)) );
      double C_increment = exp(-r * T)* max(S_T - K, 0);
      double P_increment = exp(-r * T)* max(K - S_T, 0);
      C = C + C_increment;  
      P = P + P_increment;
      //cout  << increment << endl;
    }
    C = C/N2;    // Stima della call-option nel blocco j-esimo
    P = P/N2;    // Stima della put-option nel blocco j-esimo
    
    C_ave_tot = C_ave_tot + C;
    C_var_tot = C_var_tot + C*C;

    P_ave_tot = P_ave_tot + P;
    P_var_tot = P_var_tot + P*P;

    //cout << C_ave_tot/(j+1) << "\t" << sqrt(C_var_tot/(j+1) - (C_ave_tot/(j+1))*(C_ave_tot/(j+1)) ) << "\t" <<
      //P_ave_tot/(j+1) << "\t" << sqrt(P_var_tot/(j+1) - (P_ave_tot/(j+1))*(P_ave_tot/(j+1)) ) << endl; 

    out_C << C_ave_tot/(j+1) << "\t" << sqrt(C_var_tot/(j+1) - (C_ave_tot/(j+1))*(C_ave_tot/(j+1)) ) /sqrt(j+1)<< endl;
    out_P << P_ave_tot/(j+1) << "\t" << sqrt(P_var_tot/(j+1) - (P_ave_tot/(j+1))*(P_ave_tot/(j+1)) ) /sqrt(j+1)<< endl;
  }

  if (-1 > 0){
  cout << endl << "---CALL-OPTION: " << endl;
  
  cout << endl << "Media globale per la C: " << endl;
  cout << C_ave_tot/N1 << endl;
  
  cout << endl << "Deviazione standard della media per la C: " << endl;
  cout << sqrt(C_var_tot/N1 - (C_ave_tot/N1)*(C_ave_tot/N1) )  << endl;

  cout << endl << "---PUT-OPTION: " << endl;

  cout << endl << "Media globale per la P: " << endl;
  cout << P_ave_tot/N1 << endl;

  cout << endl << "Deviazione standard della media per la P: " << endl;
  cout << sqrt(P_var_tot/N1 - (P_ave_tot/N1)*(P_ave_tot/N1) )  << endl;
  }

  out_C.close();
  out_P.close();

  // Si effettua lo stesso calcolo con incrementi temporali più ristretti

  ofstream out_CI("Call-Option-progressive.txt");
  ofstream out_PI("Put-Option-progressive.txt");

  int N_t = 20; // Numero di intervalli temporali

  C_ave_tot = 0;  // Media globale:media delle medie sui blocchi // call option
  C_var_tot = 0;    // Incertezza globale come deviazione standard della media

  P_ave_tot = 0;  // Media globale:media delle medie sui blocchi // put option
  P_var_tot = 0;    // Incertezza globale come deviazione standard della media

  // Deviazione standard della media su N1 blocchi: la variabile "A_i" è la stima della call C su ciascun blocco

  for(int j=0; j<N1; j++){

    double C  = 0; // Inizializzo la variabile associata al prezzo della call-option
    double P  = 0; // Inizializzo la variabile associata al prezzo della put-option

    for(int i=0; i<N2; i++){    // Blocco j-esimo: ripeto N2 volte la stima di S(t) per calcolare la Call C
      double S_T = S_0;
      for(int t=0; t<N_t; t++){
        S_T = S_T * exp((r - 0.5 * sigma*sigma) * (T/N_t) + sigma*rnd.Gauss(0,sqrt( (double) T / N_t) )  );   
      }
      double C_increment =  exp(-r * (double) T / 1.0) * max(S_T - K, 0);
      double P_increment =  exp(-r * (double) T / 1.0) * max(K - S_T, 0);
      C = C + C_increment;  
      P = P + P_increment;
      //cout  << increment << endl;
    }
    C = C/N2;    // Stima della call-option nel blocco j-esimo
    P = P/N2;    // Stima della put-option nel blocco j-esimo

    C_ave_tot = C_ave_tot + C;
    C_var_tot = C_var_tot + C*C;

    P_ave_tot = P_ave_tot + P;
    P_var_tot = P_var_tot + P*P;

    //cout << C_ave_tot/(j+1) << "\t" << sqrt(C_var_tot/(j+1) - (C_ave_tot/(j+1))*(C_ave_tot/(j+1)) ) << "\t" <<
      //P_ave_tot/(j+1) << "\t" << sqrt(P_var_tot/(j+1) - (P_ave_tot/(j+1))*(P_ave_tot/(j+1)) ) << endl; 

    out_CI << C_ave_tot/(j+1) << "\t" << sqrt(C_var_tot/(j+1) - (C_ave_tot/(j+1))*(C_ave_tot/(j+1)) ) /sqrt(j+1) << endl;
    out_PI << P_ave_tot/(j+1) << "\t" << sqrt(P_var_tot/(j+1) - (P_ave_tot/(j+1))*(P_ave_tot/(j+1)) ) /sqrt(j+1) << endl;
  }

  out_CI.close();
  out_PI.close();
  
  return 0;
}



/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
