/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include "random.h"

using namespace std;
 
int main (int argc, char *argv[]){

   Random rnd;
   int seed[4];
   int p1, p2;
   ifstream Primes("Primes");
   if (Primes.is_open()){
      Primes >> p1 >> p2 ;
   } else cerr << "PROBLEM: Unable to open Primes" << endl;
   Primes.close();

   ifstream input("seed.in");
   string property;
   if (input.is_open()){
      while ( !input.eof() ){
         input >> property;
         if( property == "RANDOMSEED" ){
            input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
            rnd.SetRandom(seed,p1,p2);
         }
      }
      input.close();
   } else cerr << "PROBLEM: Unable to open seed.in" << endl;

   rnd.SaveSeed();

  // Esercizio 2.2: Randow walk
  // Si comincia da un random walk discreto in 3D:

  int N1 = 200;  // Numero di Random Walk per ogni Batch
  int N2 = 50;  // Numero di Batch
  
  int N = 50; // Numero di passi

  ofstream out1("RandomWalk_discrete.txt");
  out1 << "Current Batch <r> " << "\t" << "Global <r> " << "Uncertainty <r>" << endl;

  ofstream out3("RandomWalk_discrete_steps.txt");
  out3 << "# of steps for each RW " << "\t" << "Global <r> " << "Uncertainty <r>" << endl;

  double final_ave_rms = 0;
  double final_var_rms = 0;

  for(int l = 1; l < 101; l++){
    
    double ave_RMS = 0;
    double var_RMS = 0;

    for(int j=0; j<N2; j++){
    // Lavoro sul batch j-esimo, effettuando N1 = 10 Random Walk

      double RMS = 0; // radice del raggio quadratico medio dei random walk mediato sul batch corrente

      for(int k=0; k<N1; k++){ 
      // Lavoro sul Random Walk k-esimo del batch j-esimo, effettuando N = 100 passi

        double r = 0;  // Posizione finale del random walk (distanza al quadrato dal centro)

        int X = 0; // Posizione iniziale X
        int Y = 0; // Posizione iniziale Y
        int Z = 0; // Posizione iniziale Z

        for(int i=0; i<l; i++){ // Esecuzione del random Walk passo per passo

          double num = rnd.Rannyu();
          if(num < (1.0/6.0)){
            X++;
          }else if(num > (1.0/6.0) && num < (2.0/6.0)){
            X--;
          }else if(num > (2.0/6.0) && num < (3.0/6.0)){
            Y++;
          }else if(num > (3.0/6.0) && num < (4.0/6.0)){
            Y--;
          }else if(num > (4.0/6.0) && num < (5.0/6.0)){
            Z++;
          }else if(num > (5.0/6.0) && num < (6.0/6.0)){
            Z--;
          }

          //cout << X << "\t" << Y << "\t" << Z << endl;
        }

        r = (X*X + Y*Y + Z*Z);
        RMS = RMS + r;
      }

      RMS = sqrt(RMS/N1);

      ave_RMS = ave_RMS + RMS;
      var_RMS = var_RMS + RMS*RMS;

      if(l == 50){
        out1 << RMS << "\t" << ave_RMS/(j+1) << "\t" 
          << sqrt( var_RMS/(j+1) - (ave_RMS/(j+1))*(ave_RMS/(j+1)) )/(sqrt(j+1)) << endl;
      }
      
      final_ave_rms = ave_RMS/(j+1);
      final_var_rms = var_RMS/(j+1);
    }
    out3 << l << "\t" << final_ave_rms << "\t"
      << sqrt( final_var_rms - final_ave_rms*(final_ave_rms) )/(sqrt(N2)) << endl;
  }

  out1.close();
  out3.close();

  // Ora si ripete il randow walk con una distribuzione uniforme nello spazio continuo 3D: 
  // L'obiettivo è campionare punti distribuiti uniformemente su una superficie sferica
  // La probabilità di trovare un punto entro l'angolo solido d\Omega = sin\theta d\theta d\phi centrato 
  // attorno al punto di coordinate (\theta , \phi) deve essere costante per ogni (\theta, \phi)
  // E' necessario quindi campionare quindi numeri pseudocasuali per l'angolo \theta distribuiti come sin\theta

  ofstream out2("RandomWalk_continuum.txt");
  
  double ave_RMS = 0;
  double var_RMS = 0;

  for(int j=0; j<N2; j++){
  // Lavoro sul batch j-esimo, effettuando N1 = 100 Random Walk

    double RMS = 0; // radice del raggio quadratico medio dei random walk del batch corrente

    for(int k=0; k<N1; k++){ 
    // Lavoro sul Random Walk k-esimo del batch j-esimo, effettuando N = 100 passi

      double r = 0;  // Posizione finale del random walk (distanza al quadrato dal centro)

      double X = 0; // Posizione iniziale X
      double Y = 0; // Posizione iniziale Y
      double Z = 0; // Posizione iniziale Z

      for(int i=0; i<N; i++){
        // chiamo l'angolo \theta t e l'angolo \phi p
        double p = rnd.Rannyu(0,2*M_PI);
        double y = rnd.Rannyu();
        // L'obiettivo è generare numeri distribuiti secondo la distribuzione normalizzata: 1/2 * sin(\theta)
        double t = acos(1 - 2*y); 
        
        X = X + sin(t)*cos(p);
        Y = Y + sin(t)*sin(p);
        Z = Z + cos(t);
        
        //cout << X << "\t" << Y << "\t" << Z << endl;
      }

      r = (X*X + Y*Y + Z*Z);
      RMS = RMS + r;

      cout << endl;
    }

    RMS = sqrt(RMS/N1);

    ave_RMS = ave_RMS + RMS;
    var_RMS = var_RMS + RMS*RMS;

    out2 << ave_RMS/(j+1) << "\t" << sqrt( var_RMS/(j+1) - (ave_RMS/(j+1))*(ave_RMS/(j+1)) ) << endl;
  }

  out2.close();
  
   return 0;
}

/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
