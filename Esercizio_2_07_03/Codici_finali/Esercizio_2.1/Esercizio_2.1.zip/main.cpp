#include "random.h"
#include <iostream>
#include <fstream>
#include <cmath>
//#include <cstdlib>
//#include "random.cpp"

using namespace std;

int main(int argc, char *argv[]) {
  cout << "Hello World!" << endl;

  Random rnd;
   int seed[6];
   int p1, p2;
   ifstream Primes("Primes");
   if (Primes.is_open()){
      Primes >> p1 >> p2 ;
   } else cerr << "PROBLEM: Unable to open Primes" << endl;
   Primes.close();

   ifstream input("seed.in");
   string property;
   if (input.is_open()){
      while ( !input.eof() ){
         input >> property;
         if( property == "RANDOMSEED" ){
            input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
            rnd.SetRandom(seed,p1,p2);
         }
      }
      input.close();
   } else cerr << "PROBLEM: Unable to open seed.in" << endl;

  // Esercizio 1.2.1 : Integrale di una funzione con metodo Monte Carlo
  // Metodo della media

  ofstream out("Integrale_metodo_media.txt");
  out <<"Blk" << "\t" << "Current <I>" << "\t" << "Global <I>" << "\t" << "Stdev <I>" << endl;
  
  int M = 100;
  int N = 100;
  int K = 50;

  double global_ave = 0;
  double global_ave_2 = 0;
  double global_stdev = 0;
  
  for(int j = 0; j < M; j++){
    // Blocco j-esimo
    double local_ave = 0;
    //double local_ave_2 = 0;
    for(int i = 0; i < N; i++){
      // Integrale i-esimo all'interno del blocco j-esimo
      double sum = 0;
      
      for(int k = 0; k < K; k++){
        double x = rnd.Rannyu();
        sum += M_PI/2 * cos(M_PI * x / 2);;
        //local_ave_2 += x*x;
      }
      sum /= K;
      local_ave += sum;
    }
    local_ave /= N;
    global_ave += local_ave;
    global_ave_2 += local_ave*local_ave;
    global_stdev = sqrt(global_ave_2/(j+1) - global_ave/(j+1)*global_ave/(j+1))/sqrt(j+1);
    out 

      << j + 1 << "\t"          // # batch
      << local_ave << "\t"            // <I> mediato sul blocco
      << global_ave/(j+1) << "\t" // <I> media globale
      << sqrt(global_ave_2/(j+1) - global_ave/(j+1)*global_ave/(j+1) )/sqrt(j+1) << endl; // <I> media globale
  }

  out.close();

  ofstream out2("average2.txt");
  out <<"Blk" << "\t" << "Current <I>" << "\t" << "Global <I>" << "\t" << "Stdev <I>" << endl;

  double global_sum = 0;
  double global_sum_2 = 0;
  double global_var = 0;

  for(int j = 0; j < 100; j++){
    double sum = 0;  // Contatore dell'integrale con il metodo della media
    double sigma = 0;  // Contatore della varianza associata all'integrale
    
    for(int i = 0; i < N; i++){
      double x = rnd.Rannyu();
      sum = sum + M_PI/2 * cos(M_PI * x / 2);
      sigma = sigma + pow(M_PI/2 * cos(M_PI * x / 2), 2);
    }
    sum = sum/N;
    global_sum = global_sum + sum;
    global_sum_2 = global_sum_2 + sigma/N;
    out2 
      << j + 1 << "\t"          // # batch
      << sum << "\t"            // <I> mediato sul blocco
      << global_sum/(j+1) << "\t" // <I> media globale
      << sqrt(global_sum_2/(j+1) - global_sum/(j+1)*global_sum/(j+1) )/sqrt(j+1) << endl; // <I> media globale
  }
  

  out2.close();

  // Esercizio 1.2.2 : Integrale definito con il metodo Montecarlo con l'importance sampling
  // Uso il metodo di rejection (d(x) = pi/2 - pi/2 x^2, sottesa dalla lorentziana h(x) = pi/2 1/(1+x^2) )

  ofstream out3("Integrale_importance_sampling.txt");

  out3 <<"#batch" <<  "Current <I>" << "\t" << "Global <I>" << "\t" << "Stedv <I> " << "\t" << endl;

  cout << endl << endl << "--- METODO DELL'IMPORTANCE SAMPLING --- Distribuzione d(x) data da una parabola:" << endl;

  int M1 = 100;  // numero di batch
  int M2 = 100;  // numero di stime dell'integrale per ciascun batch

  double N_2 = 25; // numero di punti per stimare ogni integrale

  double pi = M_PI;
  //double x_c = 1.0;
  
  double sum_tot = 0;    // media globale dell'integrale
  double var_tot = 0;  // deviazione standard della media

  for(int a = 0; a < M1; a++){

    double sum_batch = 0;  // media dell'integrale del batch corrente
    double var_batch = 0; // deviazione standard del batch corrente

    for(int b=0; b<M2; b++){

      int counter2 = 0;              // Numero di punti discreti x_i validi per l'importance sampling
      double sum_imp_b = 0;        // Inizializzo la somma per l'importance    sampling
      double var_imp_b = 0;        // Inizializzo la varianza per l'importance    sampling
      
      for(int i = 0 ; i < N_2; i++){  // INIZIA CICLO FOR PER LA STIMA DELL'INTEGRALE

        double z = rnd.Rannyu();
        double x = tan((pi/4.0) * (z - 0.0));  // Genero punti x su [0,1] direttamente con una distribuzione lorentziana,
        //cout << endl << x << endl;
        // la quale sottende la funzione di probabilità d(x)

        double h_x = (4.0/pi) * (1.0/(1.0 + x*x)); // La h(x) DEVE essere normalizzata

        double y = rnd.Rannyu(); // Genero punti y su [0,1] direttamente con una distribuzione lorentziana,

        double p_x = -(4.0 / pi)*x*x + (4.0 / pi);     // distribuzione di probabilità d(x) con cui scelgo gli x_i discreti // La normalizzazione, per l'accept-reject,           deve essere tale da sottendere la d(x) sotto la g(x)

        if(y < (p_x / h_x) ){              // y < d(x) / d_max 
          double increment = (pi/2.0)  * cos(pi * x / 2.0) / ( (-pi*x*x/2.0 + pi/2.0)*(3.0/pi) );
          sum_imp_b = sum_imp_b + increment;
          // L'integranda è f(x) / d(x) ; Ho tenuto conto anche della normalizzazione N(d) = (4/pi)
          var_imp_b = var_imp_b + increment*increment; 
          counter2++;
          //cout << endl << x;
        }

      }  // FINISCE CICLO FOR PER LA STIMA DELL'INTEGRALE

      sum_imp_b = sum_imp_b / counter2;
      var_imp_b = sqrt(var_imp_b - sum_imp_b*sum_imp_b) / counter2;

      //cout << sum_imp_b << "\t" << var_imp_b << endl;

      sum_batch = sum_batch + sum_imp_b;
      var_batch = var_batch + var_imp_b;
      
    }
    sum_batch = sum_batch / M2;  // <I> : media degli integrali nel batch
    var_batch = var_batch / M2;  // sigma_i

    sum_tot = sum_tot + sum_batch;
    var_tot = var_tot + sum_batch*sum_batch;

    out3 
      << a + 1 << "\t"      // #bathc
      << sum_batch << "\t"  // <I> mediata sul blocco
      << sum_tot/(a+1) << "\t" // <I> media globale
      << sqrt(var_tot/(a+1) - (sum_tot/(a+1)) * (sum_tot/(a+1)) )/sqrt(a+1) << endl; // <I> deviazione standard della media
  }

  
  //cout << "L'integrale definito vale: " << sum_imp_b << endl;
  //cout << "L'incertezza vale: " << var_imp_b << endl; 

  //cout << endl << " --- Usato numero di punti pari a: " << counter2 << endl;

  out3.close();

  return 0;
}