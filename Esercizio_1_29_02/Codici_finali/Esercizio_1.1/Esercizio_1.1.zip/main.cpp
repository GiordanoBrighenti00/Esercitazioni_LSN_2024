#include "random.h"
#include <iostream>
#include <fstream>
#include <cmath>
#include <armadillo>
//#include <cstdlib>
//#include "random.cpp"

using namespace std;

int main(int argc, char *argv[]) {
  cout << "Hello World!" << endl;

  Random rnd;
   int seed[4];
   int p1, p2;
   ifstream Primes("Primes");
   if (Primes.is_open()){
      Primes >> p1 >> p2 ;
   } else cerr << "PROBLEM: Unable to open Primes" << endl;
   Primes.close();

   ifstream input("seed.in");
   string property;
   if (input.is_open()){
      while ( !input.eof() ){
         input >> property;
         if( property == "RANDOMSEED" ){
            input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
            rnd.SetRandom(seed,p1,p2);
         }
      }
      input.close();
   } else cerr << "PROBLEM: Unable to open seed.in" << endl;
  
  ofstream out("average.txt");

  // Genero in totale N batch di M numeri pseudocasuali ciascuna
  int N = 100;
  int M = 150;

  double global_average = 0;  // media delle medie dei batch su k = 1, ..., N batch
  double global_average2 = 0; // media dei quadrati delle medie dei batch su k = 1, ..., N batch
  double global_variance = 0;  // varianza delle medie dei batch su k = 1, ..., N batch

   for(int i=0; i<N; i++){
     double sum = 0;
     double sum2 = 0;
     for(int j=0; j<M; j++){       // inizia ciclo for interno: campiono i random all'interno del batch
       
       double random_num = rnd.Rannyu();
       sum = sum + random_num;
     }                             // termina ciclo for interno: chiuso il batch corrente
    sum = sum/M;                  // Ho calcolato la media A_i sul batch appena chiuso
    sum2 = sum*sum;                // Ho calcolato il quadrato della media A_i sul batch appena chiuso

     global_average = global_average + sum;
     global_average2 = global_average2 + sum2;

     global_variance = global_average2/(i+1) - (global_average/(i+1) ) * (global_average/(i+1) );

     out << global_average/(i+1) << "\t" << sqrt(global_variance)/(sqrt(i+1)) << endl;
   }
   
   rnd.SaveSeed();
   out.close();

  // ora stimo la deviazione standard, con lo stesso numero di batch
  // ora la singola variabile non è più il numero pseudocasuale r, ma bensì (r - 0.5)^2

  ofstream out2("variance.txt");

  global_average = 0;  // media delle deviazioni standard dei batch su k = 1, ..., N batch
  global_average2 = 0; // media dei quadrati delle deviazioni standard dei batch su k = 1, ..., N batch
  global_variance = 0;  // varianza delle deviazioni standard dei batch su k = 1, ..., N batch

   for(int i=0; i<N; i++){
     double sum = 0;
     double sum2 = 0;
     for(int j=0; j<M; j++){       // inizia ciclo for interno: campiono i random all'interno del batch

       double random_num = rnd.Rannyu();
       sum = sum + (random_num - 0.5)*(random_num - 0.5);
     }                             // termina ciclo for interno: chiuso il batch corrente
    sum = sum/M;                  // Ho calcolato la media A_i sul batch appena chiuso
    sum2 = sum*sum;                // Ho calcolato il quadrato della media A_i sul batch appena chiuso

     global_average = global_average + sum;
     global_average2 = global_average2 + sum2;

     global_variance = global_average2/(i+1) - (global_average/(i+1) ) * (global_average/(i+1) );

     out2 << global_average/(i+1) << "\t" << sqrt(global_variance)/(sqrt(i+1)) << endl;
   }

   rnd.SaveSeed();
   out2.close();
  
  

  // Test del chi quadro: suddivido l'intervallo [0.1] in M sotto-intervalli. Generando N numeri pseudo-casuali su [0.1] M volte, conto quanti numeri,
  // degli N generati ad ogni ciclo, appartengono al sotto-intervallo j-esimo.
  // Il numero di conteggi associato all'intervalllo i-esimo sarà n_i. Il valore atteso del numero di conteggi in ogni intervallo sarà N/M

  N = 10000;
  M = 100;

  double E = double(N/M);

  ofstream out3("chi_test.txt");

  out3 << "#" << "\t" << "chi_test" << endl;
  
  for(int k = 0; k < 100; k++){
    // Ripeto 10000 volte il calcolo del chi-quadro
    
    double chi2 = 0;
    arma::rowvec x(M, arma::fill::zeros);
    
    for(int i = 0; i < N; i++){
      
      double r = rnd.Rannyu();
      int index = floor(r*100);
      x(index) = x(index) + 1;
    }

    for(int j = 0; j < M; j++){
      chi2 = chi2 + (x(j) - E) * (x(j) - E)/E;
    }

    out3 << k << "\t" << chi2 << endl;
    
  }

  out3.close();
  rnd.SaveSeed();
  return 0;
}

