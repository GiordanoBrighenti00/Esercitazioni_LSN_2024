#include "random.h"
#include <iostream>
#include <fstream>
#include <cmath>
//#include <cstdlib>
//#include "random.cpp"

using namespace std;

int main(int argc, char *argv[]) {
  cout << "Hello World!" << endl;

  Random rnd;
   int seed[8];
   int p1, p2;
   ifstream Primes("Primes");
   if (Primes.is_open()){
      Primes >> p1 >> p2 ;
   } else cerr << "PROBLEM: Unable to open Primes" << endl;
   Primes.close();

   ifstream input("seed.in");
   string property;
   if (input.is_open()){
      while ( !input.eof() ){
         input >> property;
         if( property == "RANDOMSEED" ){
            input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
            rnd.SetRandom(seed,p1,p2);
         }
      }
      input.close();
   } else cerr << "PROBLEM: Unable to open seed.in" << endl;

  // Esercizio 1.3: Esperimento di Buffon

  double d = 1.0;  // Distanza tra segmenti paralleli
  double L = 0.82;  // Lunghezza dell'ago

  int N = 8000;  // Numero di lanci totale
  int num = 0;  // Numero di lanci che non intersecano

  for(int i = 0; i < N; i++){
    
    double z = rnd.Rannyu(0,d);  // Generazione della ordinata z1 per il CM

    //double cosen = (z2 - z1) / sqrt( (x2 - x1)*(x2 - x1) - (z2 - z1)*(z2 - z1) );  
    
    double phi = rnd.Rannyu(0,M_PI);  // Generazione di un angolo pseudo-casuale tra 0 e PI

    if(z - L/2 * abs(cos(phi)) > 0 && z + L/2 * abs(cos(phi)) < d){
      num++;
    }
  }

  double n = 1.0 - (double)num/N;  // Frazione di lanci che intersecano il segmento
  cout << num << endl;

  
  double real_pi = 2 * L / (d * n);
  cout << "Il valore di pi greco calcolato con il metodo di Buffon è: " << real_pi << endl;

  // --- Si ripete l'esercizio senza la conoscenza a priori del PI

  ofstream out("Buffon.txt");
  out << "Current pi" << "\t" << "Ave_pi" << "\t"<< "Stdev_pi" << endl;

  int M = 100;  // Numero di blocchi

  double global_pi_est = 0;
  double global_pi_est_2 = 0;
  double global_stdev_pi_est = 0;

  for(int j = 0; j < M; j++){
    double pi_est = 0;
    double number = 0;
    double N2 = 0; // numero di punti che cadono nel cerchio
    
    for(int i = 0; i < 50000; i++){ // Un blocco è semplicemente la ripetizione di N tiri
      // Il valore di aspettazione di ogni blocco è semplicemente la stima di pi
      double z = rnd.Rannyu(0,d);

      double z1 = rnd.Rannyu(z-L/2,z+L/2);
      double x1 = rnd.Rannyu(-L/2,L/2);

      double radius = sqrt( (z1 - z)*(z1 - z) + x1*x1 );
      if(radius < L/2){
        N2++;
        double cosin = (z-z1)/radius;
        if(z - L/2 * abs(cosin) > 0 && z + L/2 * abs(cosin) < d){
          number++;
        }
      }

    }
    double n_final = 1.0 - (double)number/N2; // Frazione di lanci che intersecano il segmento
    pi_est = 2 * L / (d * n_final);

    global_pi_est += pi_est;
    global_pi_est_2 += pi_est * pi_est;
    global_stdev_pi_est = sqrt(global_pi_est_2/(j+1) - global_pi_est/(j+1) * global_pi_est/(j+1) ) /sqrt(j+1);
    out << pi_est << "\t" << global_pi_est/(j+1) << "\t" << global_stdev_pi_est << endl;
  }
  

  //double n_final = 1.0 - (double)number/N2;  // Frazione di lanci che intersecano il segmento
  //cout << number << endl;


  //double real_pi_final = 2 * L / (d * n_final);
  //cout << "Il valore di pi greco calcolato con il metodo di Buffon è: " << real_pi_final << endl;

  out.close();
  return 0;
}