#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include "random.h"

using namespace std;

int main(int argc, char *argv[]) {
  cout << "Hello World!" << endl;

  Random rnd;
   int seed[8];
   int p1, p2;
   ifstream Primes("Primes");
   if (Primes.is_open()){
      Primes >> p1 >> p2 ;
   } else cerr << "PROBLEM: Unable to open Primes" << endl;
   Primes.close();

   ifstream input("seed.in");
   string property;
   if (input.is_open()){
      while ( !input.eof() ){
         input >> property;
         if( property == "RANDOMSEED" ){
            input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
            rnd.SetRandom(seed,p1,p2);
         }
      }
      input.close();
   } else cerr << "PROBLEM: Unable to open seed.in" << endl;

  // Esercizio 1.2.1: Campionare distribuzioni esponenziali e di Cauchy_Lorentz usando l'inversione della cumulativa

  int N = 1500;  // Quantità di numeri pseudo-casuali generati

  double lambda = 0.8;  // Parametro della distribuzione esponenziale
  double gamma = 0.2;  // Parametro della distribuzione di Cauchy_Lorentz
  double mu = 0.52;  // Parametro della distribuzione di Cauchy_Lorentz
  double pi = M_PI;  // Pigreco
  double gaus_sigma = 1; // Incertezza della gaussiana
  double gaus_mu = 0; // Centroide della gaussiana

  ofstream out("distributions.txt");
  out << "y uniforme" << "\t" << "x esponenziale" << "\t" << "x Cauchy_Lorenz" << "\t" << "x gaussiana" << endl;
  out << " " << "\t" << " " << "\t" << " " << "\t" << " " << endl;

  for(int i = 0; i < N; i++){
    double y = rnd.Rannyu();
    double x1 = -double(1/lambda) * log(1 - y);
    double x2 = gamma * tan(pi * (y - 0.5) ) + mu;
    double r = gaus_mu + sqrt(-2*gaus_sigma*gaus_sigma*log(1-y));
    double x3 = r * sin(2*pi*rnd.Rannyu());

    out << y << "\t" << x1 << "\t" << x2 << "\t" << x3 << endl;
  }

  out.close();

  // Esercizio 1.2.2: Verificare le distrubuzioni limite, usando come variabile non più il singolo numero pseudo-casuale, ma la somma di 1,2,10,100 numeri pseudo-casuali
  lambda = 1;
  gamma = 1;
  mu = 0;
  int M = 10000;
  
  ofstream out2("distributions_limit_N_2.txt");
  out2 << "y uniforme" << "\t" << "x esponenziale" << "\t" << "x Cauchy_Lorenz" << "\t" << "x gaussiana" << endl;
  out2 << " " << "\t" << " " << "\t" << " " << "\t" << " " << endl;

  N = 2;

  for(int j=0; j<M; j++){

    double SN_y = 0;  // Somma dei numeri generati con distribuzione uniforme
    double SN_x1 = 0;  // Somma dei numeri generati con distribuzione esponenziale
    double SN_x2 = 0;  // Somma dei numeri generati con distribuzione di Cauchy_Lorentz
    double SN_x3 = 0;  // Somma dei numeri generati con distribuzione gaussiana
    
    for(int i=0; i<N; i++){
      double y = rnd.Rannyu();
      double x1 = -double(1/lambda) * log(1 - y);
      double x2 = gamma * tan(pi * (y - 0.5) ) + mu;
      double r = gaus_mu + sqrt(-2*gaus_sigma*gaus_sigma*log(1-y));
      double x3 = r * sin(2*pi*rnd.Rannyu());
      
      SN_y = SN_y + y;
      SN_x1 = SN_x1 + x1;
      SN_x2 = SN_x2 + x2;
      SN_x3 = SN_x3 + x3;
      
    }

    out2 << (double)SN_y / N << "\t" << (double)SN_x1 / N << "\t" << (double)SN_x2 / N << "\t" << (double)SN_x3 / N << endl;
    
  }
  out2.close();

  ofstream out3("distributions_limit_N_10.txt");
  out3 << "y uniforme" << "\t" << "x esponenziale" << "\t" << "x Cauchy_Lorenz" << "\t" << "x gaussiana" << endl;
  out3 << " " << "\t" << " " << "\t" << " " << "\t" << " " << endl;

  N = 10;

  for(int j=0; j<M; j++){

    double SN_y = 0;  // Somma dei numeri generati con distribuzione uniforme
    double SN_x1 = 0;  // Somma dei numeri generati con distribuzione esponenziale
    double SN_x2 = 0;  // Somma dei numeri generati con distribuzione di Cauchy_Lorentz
    double SN_x3 = 0;  // Somma dei numeri generati con distribuzione gaussiana
    
    for(int i=0; i<N; i++){
      double y = rnd.Rannyu();
      double x1 = -double(1/lambda) * log(1 - y);
      double x2 = gamma * tan(pi * (y - 0.5) ) + mu;
      double r =  gaus_mu + sqrt(-2*gaus_sigma*gaus_sigma*log(1-y));
      double x3 = r * sin(2*pi*rnd.Rannyu());

      SN_y = SN_y + y;
      SN_x1 = SN_x1 + x1;
      SN_x2 = SN_x2 + x2;
      SN_x3 = SN_x3 + x3;

    }

    out3 << (double)SN_y / N << "\t" << (double)SN_x1 / N << "\t" << (double)SN_x2 / N << "\t" << (double)SN_x3 / N << endl;

  }
  out3.close();

  ofstream out4("distributions_limit_N_100.txt");
  out4 << "y uniforme" << "\t" << "x esponenziale" << "\t" << "x Cauchy_Lorenz" << "\t" << "x gaussiana" << endl;
  out4 << " " << "\t" << " " << "\t" << " " << "\t" << " " << endl;

  N = 100;

  for(int j=0; j<M; j++){

    double SN_y = 0;  // Somma dei numeri generati con distribuzione uniforme
    double SN_x1 = 0;  // Somma dei numeri generati con distribuzione esponenziale
    double SN_x2 = 0;  // Somma dei numeri generati con distribuzione di Cauchy_Lorentz
    double SN_x3 = 0;  // Somma dei numeri generati con distribuzione gaussiana
    
    for(int i=0; i<N; i++){
      double y = rnd.Rannyu();
      double x1 = -double(1/lambda) * log(1 - y);
      double x2 = gamma * tan(pi * (y - 0.5) ) + mu;
      double r = gaus_mu + sqrt(-2*gaus_sigma*gaus_sigma*log(1-y));
      double x3 = r * sin(2*pi*rnd.Rannyu());

      SN_y = SN_y + y;
      SN_x1 = SN_x1 + x1;
      SN_x2 = SN_x2 + x2;
      SN_x3 = SN_x3 + x3;

    }

    out4 << (double)SN_y / N << "\t" << (double)SN_x1 / N << "\t" << (double)SN_x2 / N << "\t" << (double)SN_x3 / N << endl;

  }
  out4.close();
  
  return 0;
}