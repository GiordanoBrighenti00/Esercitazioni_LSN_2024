/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include "random.h"

using namespace std;

// -------------------------- INIZIO DELLE FUNZIONI -----------------------------------------------------

double psi_1s(double x, double y, double z){ // Funzione d'onda del ground state dell'idrogeno
  return exp(-sqrt(x*x + y*y + z*z));
}

double psi_2p(double x, double y, double z){ // Funzione d'onda dello stato eccitato dell'idrogeno con n = 2 e l = 1
  return sqrt(x*x + y*y + z*z) * exp(-sqrt(x*x + y*y + z*z) / 2.0) * (z/sqrt(x*x + y*y + z*z));
}

double min(double x, double y){ // Funzione che restituisce il minimo tra due valori
  if (x < y){return x;} else {return y;}
}

double Box_Muller(double sigma, double mu, Random &rnd){// Funzione che genera un numero casuale distribuito secondo una Gaussiana
    double U1_x = rnd.Rannyu();
    double U2_x = rnd.Rannyu();

    double pi = M_PI;

    double Z1_x = mu + sqrt(-2 * sigma*sigma * log(U1_x)) * cos(2 * pi * U2_x);
    double Z2_x = mu + sqrt(-2 * sigma*sigma * log(U1_x)) * sin(2 * pi * U2_x);

    return Z2_x;
}

double Gauss_3D(double x1,double  x2, double y1,double  y2,double  z1, double z2, double sigma){
  return exp( ( (x1- x2)*(x1- x2) + (y1 - y2)*(y1- y2) + (z1 - z2)*(z1- z2) ) / (2*sigma*sigma) );
}

void Metro_Walk(bool psi_selec,double L, double sigma, double III, double x_c , double y_c, double z_c , string filename1, string filename2, int N, int N1, int M, Random rnd){
  // psi_selec: inserire 1(true) se si vole campionare psi_1s, oppure 0(false) se si vuole campionare psi_2p
  // sigma: inserire la varianza della distribuzione gaussiana
  // L: cutoff dei numeri pseudo-casuali generati
  // III: inserire la metà del lato del cubo da cui estraggo il punto di partenza
  // x_c, y_c, z_c: inserire le coordinate del punto centrale del cubo da cui estraggo il punto di partenza
  // filename1: inserire il nome del file .txt in cui vengono salvate le posizioni per ogni singolo step
  // filename2: inserire il nome del file .txt in cui vengono salvati gli RMS, comprensivi di media e incertezza, per ciascun batch
  // N: inserire il numero di step per ogni batch
  // N1: inserire il numero di step necessari per l'equilibrazione
  // M: inserire il numero di batch
  // rnd: inserire l'oggetto di generazione di numeri pseudocasuali elaborato all'inizio del main
  
  // Inzializzo la posizione nel cubo di lato L centrato nell'origine
  double x = rnd.Rannyu(-III + x_c ,III + x_c);
  double y = rnd.Rannyu(-III + y_c ,III + y_c);
  double z = rnd.Rannyu(-III + z_c ,III + z_c);

  ofstream out1(filename1);
  ofstream out2(filename2);

  out1 << "X" << "\t " << "Y" << "\t " << "Z" << endl;
  out2 << "#" << "\t" << "Current_RMS" << "\t " << "Ave_RMS" << "\t " << "Stdev_RMS" << "\t" << "Ave_accept"<< endl;

  double ave_rms = 0;    // Inizializzo la media globale sui blocchi del raggio medio
  double ave_rms2 = 0;
  double ave_mean = 0;  // Inizializzo la media globale sui blocchi della probabilità di accettazione

  // Inizio del blocco di equilibrazione, in cui non devo salvare medie globali

  for(int i=0; i < N1; i++){ // Si lavora sul passo i-esimo del batch di equilibrazione
    // Genero il candidato punto successivo del rando walk con distribuzione di probabilità:
    // p(x) = 1/(2L); p(y) = 1/(2L); p(z) = 1/(2L)

    double d_x = Box_Muller(sigma, 0, rnd);
    double d_y = Box_Muller(sigma, 0, rnd);
    double d_z = Box_Muller(sigma, 0, rnd);

    while(d_x*d_x + d_y*d_y + d_z*d_z > L){// Non si può evadere il cutoff
      d_x = Box_Muller(sigma, 0, rnd);
      d_y = Box_Muller(sigma, 0, rnd);
      d_z = Box_Muller(sigma, 0, rnd);
    }

    //cout << d_x << " " << d_y << " " << d_z << endl;

    // Propongo il candidato della nuova posizione del random walk
    double xnew = x + d_x;
    double ynew = y + d_y;
    double znew = z + d_z;
    
    // Computo della probabilità di accettazione
    double A = 0;
    if(psi_selec){
      A = min(1.0, psi_1s(xnew,ynew,znew)*psi_1s(xnew,ynew,znew) / (psi_1s(x,y,z)*psi_1s(x,y,z)) );
    }else{
      A = min(1.0, psi_2p(xnew,ynew,znew)*psi_2p(xnew,ynew,znew) / (psi_2p(x,y,z)*psi_2p(x,y,z)) ); 
    }

    double test = rnd.Rannyu(0,1);

    //Accettazione
    if(test < A){ x = xnew, y = ynew, z = znew;}

    out1 << x << "\t " << y << "\t " << z << endl;
  }
  // Fine del blocco di equilibrazione

  // Inizio dei blocchi di evoluzione post-equilibraizone, dove accumulo statistica attraverso medie globali

  for(int j = 0; j < M; j++){// Si lavora nel batch j-esimo
    double mean = 0;
    double r  = 0;
    
    for(int i=0; i < N; i++){ // Si lavora sul passo i-esimo del batch j-esimo
      // Genero il candidato punto successivo del rando walk con distribuzione di probabilità:
      // p(x) = 1/(2L); p(y) = 1/(2L); p(z) = 1/(2L)

      double d_x = Box_Muller(sigma, x, rnd);
      double d_y = Box_Muller(sigma, x, rnd);
      double d_z = Box_Muller(sigma, x, rnd);

      while(d_x*d_x + d_y*d_y + d_z*d_z > L){// Non si può evadere il cutoff
        d_x = Box_Muller(sigma, 0, rnd);
        d_y = Box_Muller(sigma, 0, rnd);
        d_z = Box_Muller(sigma, 0, rnd);
      }
      
      // Propongo il candidato della nuova posizione del random walk
      double xnew = x + d_x;
      double ynew = y + d_y;
      double znew = z + d_z;

      // Computo della probabilità di accettazione
      double A = 0;
      if(psi_selec){
        A = min(1.0, psi_1s(xnew,ynew,znew)*psi_1s(xnew,ynew,znew) / (psi_1s(x,y,z)*psi_1s(x,y,z)) );
      }else{
        A = min(1.0, psi_2p(xnew,ynew,znew)*psi_2p(xnew,ynew,znew) / (psi_2p(x,y,z)*psi_2p(x,y,z)) ); 
      }

      double test = rnd.Rannyu(0,1);

      //Accettazione
      if(test < A){ x = xnew, y = ynew, z = znew;
          mean = mean + A;
      }
      
      out1 << x << "\t " << y << "\t " << z << endl;
      
      r = r + sqrt(x*x + y*y  + z*z);
      
    }
    ave_rms = ave_rms + (r / N);
    ave_rms2 = ave_rms2 + (r / N)*(r / N);
    ave_mean = ave_mean + mean / N;

    // Su una sola riga, vengono stampati...
    out2 << (j+1) << "\t"                                                           // il numero del blocco
      <<  (r/N) << "\t "                                                            // il raggio medio del blocco corrente          
      << (ave_rms/(j+1)) << "\t "                                                   // la media globale del raggio medio fino al blocco corrente
      << sqrt(ave_rms2 / (j+1) - (ave_rms/(j+1))*(ave_rms/(j+1))) /sqrt(j+1) << "\t"  // la rispettiva deviazione standard della media
      << (ave_mean/(j+1)) << endl;                                                   // la media globale della probabilità di accettazione fino al blocco corrente      
    
  }
  // Fine del data-blocking
  out1.close();
  out2.close();
}

// ----------------------- FINE DELLE FUNZIONI --------------------------------------------

int main (int argc, char *argv[]){
  Random rnd;
  int seed[5];
   int p1, p2;
   ifstream Primes("Primes");
   if (Primes.is_open()){
      Primes >> p1 >> p2 ;
   } else cerr << "PROBLEM: Unable to open Primes" << endl;
   Primes.close();

   ifstream input("seed.in");
   string property;
   if (input.is_open()){
      while ( !input.eof() ){
         input >> property;
         if( property == "RANDOMSEED" ){
            input >> seed[0] >> seed[1] >> seed[2] >> seed[3];
            rnd.SetRandom(seed,p1,p2);
         }
      }
      input.close();
   } else cerr << "PROBLEM: Unable to open seed.in" << endl;

   for(int i=0; i<20; i++){
      //cout << rnd.Rannyu() << endl;
   } 
  rnd.SaveSeed();
  

  // Esercizio 5.1: Campiono la distibuzione di probabilità PSI_n_l con l'algoritmo Metropolis
  // p(r,t) = 1/(sqrt(pi*a_0^3)) * exp(-r/a_0)      p(r,t)= 1/(sqrt(pi*a_0^3)) * exp(-r/2*a_0) * cos(t)
  // Il raggio è scritto in unità del raggio di Bohr a_0

  //double pi = M_PI;
  //double a_0 = 0.52917721067; // Servirebbe solo per una eventuale normalizzazione

  // DATA BLOCKING: l'interesse è il campionamento della distribuzione dei punti sul random walk: dunque ogni blocco (batch) corrisponde al
  // singolo random walk, dal momento che il raggio quadratico medio, che è il valore di aspettazione del singolo batch, utilizza già tutti i pti del    // random walk
  
  double III = 0; // Consulatre la funzione Metro_Walk prima del main per il significato di tali grandezze
  int N, N1, M = 0; // Consulatre la funzione Metro_Walk prima del main per il significato di tali grandezze
  double sigma = 0;
  double L  = 0;
  // Ogni singolo random walk per generare la distribuzione di punti secondo |\psi_nl|^2 è affidata alla funzione Metro_Walk

  //funzione d'onda psi_1s campionata con una distribuzione T(x|y) uniforme
  L = 2.18, sigma = 3.48, III = 1.1, M = 25, N = 5000, N1 = 100000; // Valori ottimali per il Metro: non modificare questa riga
  Metro_Walk(true,L, sigma, III, 0, 0, 0, "points_1s.txt", "rms_1s.txt", N, N1, M, rnd);

  //funzione d'onda psi_2p campionata con una distribuzione T(x|y) uniforme
  L = 6.87, sigma = 3.48, III = 1.1, M = 25, N = 5000, N1 = 100000; // Valori ottimali per il Metro: non modificare questa riga
  //Metro_Walk(false, L, sigma,  III, 0, 0, 0, "points_2p.txt", "rms_2p.txt", N, N1, M, rnd);

  //funzione d'onda psi_1s campionata con una distribuzione T(x|y) uniforme, scegliendo un punto di partenza lontano
  L = 1.88, sigma = 3.48, III = 1.1, M = 25, N = 25000 ,N1 = 200000; // Valori ottimali per il Metro: non modificare questa riga
  //Metro_Walk(true, L, sigma, III, 140, 60, -190, "points_1s_far.txt", "rms_1s_far.txt", N, N1, M, rnd);

  //funzione d'onda psi_2p campionata con una distribuzione T(x|y) uniforme, scegliendo un punto di partenza lontano
  L = 6.56, sigma = 3.48, III = 1.1, M = 25, N = 5000, N1 = 200000; // Valori ottimali per il Metro: non modificare questa riga
  //Metro_Walk(false, L, sigma, III, 140, 60, -190, "points_2p_far.txt", "rms_2p_far.txt", N, N1, M, rnd);
  
  return 0;
}

/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/