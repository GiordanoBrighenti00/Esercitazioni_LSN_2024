#include <stdio.h>
#inc

void Metro_Walk(bool psi_selec, double L, double III, double x_c , double y_c, double z_c , string filename1, string filename2, int N, int N1, int M, Random rnd){
  // psi_selec: inserire 1(true) se si vole campionare psi_sigma,mu, oppure 0(false) se no
  // L: inserire il passo dell'integrazione
  // III: inserire la metà del lato del cubo da cui estraggo il punto di partenza
  // x_c, y_c, z_c: inserire le coordinate del punto centrale del cubo da cui estraggo il punto di partenza
  // filename1: inserire il nome del file .txt in cui vengono salvate le posizioni per ogni singolo step
  // filename2: inserire il nome del file .txt in cui vengono salvati gli RMS, comprensivi di media e incertezza, per ciascun batch
  // N: inserire il numero di step per ogni batch
  // N1: inserire il numero di step necessari per l'equilibrazione
  // M: inserire il numero di batch
  // rnd: inserire l'oggetto di generazione di numeri pseudocasuali elaborato all'inizio del main

  // Inzializzo la posizione nel cubo di lato L centrato nell'origine
  double x = rnd.Rannyu(-III + x_c ,III + x_c);
  double y = rnd.Rannyu(-III + y_c ,III + y_c);
  double z = rnd.Rannyu(-III + z_c ,III + z_c);

  ofstream out1(filename1);
  ofstream out2(filename2);

  out1 << "X" << "\t " << "Y" << "\t " << "Z" << endl;
  out2 << "#" << "\t" << "Current_RMS" << "\t " << "Ave_RMS" << "\t " << "Stdev_RMS" << "\t" << "Ave_accept"<< endl;

  double ave_rms = 0;    // Inizializzo la media globale sui blocchi del raggio medio
  double ave_rms2 = 0;
  double ave_mean = 0;  // Inizializzo la media globale sui blocchi della probabilità di accettazione

  // Inizio del blocco di equilibrazione, in cui non devo salvare medie globali

  for(int i=0; i < N1; i++){ // Si lavora sul passo i-esimo del batch di equilibrazione
    // Genero il candidato punto successivo del rando walk con distribuzione di probabilità:
    // p(x) = 1/(2L); p(y) = 1/(2L); p(z) = 1/(2L)

    double d_x = rnd.Rannyu(-L,L);
    double d_y = rnd.Rannyu(-L,L);
    double d_z = rnd.Rannyu(-L,L);

    // Propongo il candidato della nuova posizione del random walk
    double xnew = x + d_x;
    double ynew = y + d_y;
    double znew = z + d_z;

    // Computo della probabilità di accettazione
    double A = 0;
    if(psi_selec){
      A = min(1.0, psi_1s(xnew,ynew,znew)*psi_1s(xnew,ynew,znew) / (psi_1s(x,y,z)*psi_1s(x,y,z)) );
    }else{
      A = min(1.0, psi_2p(xnew,ynew,znew)*psi_2p(xnew,ynew,znew) / (psi_2p(x,y,z)*psi_2p(x,y,z)) ); 
    }

    double test = rnd.Rannyu(0,1);

    //Accettazione
    if(test < A){ x = xnew, y = ynew, z = znew;}

    out1 << x << "\t " << y << "\t " << z << endl;
  }
  // Fine del blocco di equilibrazione

  // Inizio dei blocchi di evoluzione post-equilibraizone, dove accumulo statistica attraverso medie globali

  for(int j = 0; j < M; j++){// Si lavora nel batch j-esimo
    double mean = 0;
    double r  = 0;

    for(int i=0; i < N; i++){ // Si lavora sul passo i-esimo del batch j-esimo
      // Genero il candidato punto successivo del rando walk con distribuzione di probabilità:
      // p(x) = 1/(2L); p(y) = 1/(2L); p(z) = 1/(2L)

      double d_x = rnd.Rannyu(-L,L);
      double d_y = rnd.Rannyu(-L,L);
      double d_z = rnd.Rannyu(-L,L);

      // Propongo il candidato della nuova posizione del random walk
      double xnew = x + d_x;
      double ynew = y + d_y;
      double znew = z + d_z;

      // Computo della probabilità di accettazione
      double A = 0;
      if(psi_selec){
        A = min(1.0, psi_1s(xnew,ynew,znew)*psi_1s(xnew,ynew,znew) / (psi_1s(x,y,z)*psi_1s(x,y,z)) );
      }else{
        A = min(1.0, psi_2p(xnew,ynew,znew)*psi_2p(xnew,ynew,znew) / (psi_2p(x,y,z)*psi_2p(x,y,z)) ); 
      }

      double test = rnd.Rannyu(0,1);

      //Accettazione
      if(test < A){ x = xnew, y = ynew, z = znew;
          mean = mean + A;
      }

      out1 << x << "\t " << y << "\t " << z << endl;

      r = r + sqrt(x*x + y*y  + z*z);

    }
    ave_rms = ave_rms + (r / N);
    ave_rms2 = ave_rms2 + (r / N)*(r / N);
    ave_mean = ave_mean + mean / N;

    // Su una sola riga, vengono stampati...
    out2 << (j+1) << "\t"                                                           // il numero del blocco
      <<  (r/N) << "\t "                                                            // il raggio medio del blocco corrente          
      << (ave_rms/(j+1)) << "\t "                                                   // la media globale del raggio medio fino al blocco corrente
      << sqrt(ave_rms2 / (j+1) - (ave_rms/(j+1))*(ave_rms/(j+1))) /sqrt(j+1) << "\t"  // la rispettiva deviazione standard della media
      << (ave_mean/(j+1)) << endl;                                                   // la media globale della probabilità di accettazione fino al blocco corrente      

  }
  // Fine del data-blocking
  out1.close();
  out2.close();
}

int main(void) {
  printf("Hello World\n");
  return 0;
}