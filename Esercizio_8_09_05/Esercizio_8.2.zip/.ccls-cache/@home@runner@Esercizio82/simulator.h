#ifndef __Simulator__
#define __Simulator__

#include <string>

using namespace std;

class Simulator{

private:
  double _mu, _sigma, _x;  // Parametri _mu e _sigma
  double _L1, _L2, _L3;  // Passi di integrazione per il Metropolis
  double _E, _E_var;  // Valore di aspettazione dell'energia <E> + rispettiva incertezza
  Random _rnd;
public:
  //Costruttori
  Simulator();
  Simulator(double mu, double sigma);
  //Distruttori
  ~Simulator();
  //Metodi
  void SetRandom(Random& rnd);
  void SetStartingPoint(double x_c);
  void SetPosition(double x);
  void SetStep(double L1, double L2, double L3);
  double GetPosition();
  double GetEnergy(bool R);
  double Psi_T(double x);
  //double GetExpectEValue();
  double Metro_Step();
  double Step_Annealing(double beta, double K);
  void Simulated_Annealing(double T, double alpha, string filename1, string filename2, double N1, double M, double N, double K);
  void Integral_Expectation_value(double K);
  double V_Potential(double x);
  double min(double x, double y);
  double Lapl_T(double x);
  double E_integrand(double x);


};

#endif // __Simulator__